// app.js
const express = require( 'express' );
const dotenv = require( 'dotenv' );
const mongoose = require( 'mongoose' );
const authRoutes = require( './routes/authRoutes' );
const orderRoutes = require( './routes/orderRoutes' );
//const MONGODB_URI = "mongodb+srv://hangoutwithani:xJfrXHdM5ab3hNiT@cluustertesting.rjfom1k.mongodb.net/?retryWrites=true&w=majority&appName=CluusterTesting";
const { register, login } = require( './controllers/authController' );
const { allUsers, newUsers, userInfo } = require( './controllers/Users' );
const { allServices, newServices, serviceInfo, allNotes, newNotes } = require( './controllers/Services' );
const { createCode } = require( './controllers/CreateCode' );
const cors = require( 'cors' );

dotenv.config();
const app = express();

// Middleware
app.use( express.json() );



// Routes
app.use( cors(
    {
        origin: '*',
        // origin: 'http://localhost:3000',
        // credentials: true,
    }
) );
// app.use( '/order', orderRoutes );
// app.post( '/auth/register', register );
// app.post( '/auth/login', login );

app.post( '/all-users', allUsers );
app.post( '/userinfo', userInfo );
app.post( '/all-services', allServices );
app.post( '/serviceinfo', serviceInfo );
app.post( '/new-user', newUsers );
app.post( '/new-services', newServices );
app.post( '/all-notes', allNotes );
app.post( '/new-notes', newNotes );
app.get( '/barcode/:text', createCode );
// app.post( '/all-services', login );
// app.post( '/new-service', login );
// app.post( '/service-notes', login );



// Start the server
const PORT = process.env.PORT || 3000;
app.listen( PORT, () =>
{
    console.log( `Server started on port ${ PORT }` );
} );

// Connect to MongoDB
mongoose.connect( process.env.MONGODB_URI_DEMO, { useNewUrlParser: true, useUnifiedTopology: true } )
    .then( () => console.log( 'Connected to MongoDB' ) )
    .catch( error => console.error( 'MongoDB connection error:', error ) );



//hangoutwithani
//xJfrXHdM5ab3hNiT
//mongodb+srv://hangoutwithani:<password>@cluustertesting.rjfom1k.mongodb.net/