const Service = require( '../models/Services' );
const short = require( 'short-uuid' );


async function allServices ( req, res )
{
    try
    {
        const { userId } = req.body;

        // get all users
        const users = await Service.find( { userId } );
        var myRes = {};
        if ( users.length > 0 )
        {
            myRes.users = users;
            myRes.status = 2;
        } else
        {
            myRes = {
                users: users,
                status: 1
            }
        }

        res.status( 200 ).json( myRes );
    } catch ( error )
    {
        console.error( error );
        res.status( 500 ).send( 'Error registering user' );
    }
}

async function newServices ( req, res )
{
    try
    {
        console.log( req.body );

        const { userId, subject, company, category, subCategory, note, price, paymentType } = req.body;
        var myRes = {};

        const serviceId = short.generate();
        const firstDate = new Date().toISOString();

        const newService = new Service( { userId, subject, company, category, subCategory, note, price, paymentType, serviceId, firstDate } );

        await newService.save();

        myRes = {
            status: 1,
            message: 'Service added successfully',
            serviceId: serviceId
        }

        res.status( 200 ).json( myRes );
        return;

    } catch ( error )
    {
        console.error( error );
        res.status( 500 ).send( 'Error registering user' );
    }
}


async function allNotes ( req, res )
{
    try
    {
        const { serviceId } = req.body;

        // get all users
        const notes = await Service.findOne( { serviceId } );
        var myRes = {};
        if ( notes.length > 0 )
        {
            myRes.message = "No notes found";
            myRes.status = 2;
        } else
        {
            myRes = {
                quotations: notes.quotations,
                status: 1
            }
        }

        res.status( 200 ).json( myRes );
    } catch ( error )
    {
        console.error( error );
        res.status( 500 ).send( 'Error registering user' );
    }
}


async function newNotes ( req, res )
{
    try
    {
        const { serviceId, note } = req.body;


        // get all users
        const notes = await Service.findOne( { serviceId } );

        var myRes = {};


        if ( notes )
        {
            console.log( notes._id );

            // get epoch time
            const entryTime = new Date().getTime().toString();


            const finalData = await Service.updateOne(

                {
                    serviceId: serviceId
                }
                ,
                {
                    $push: {
                        quotations: {
                            note, entryTime
                        }
                    }
                }
                ,
                { new: true }
            );

            const newNotes = await Service.findOne( { serviceId } );


            myRes = {
                inputRes: finalData,
                status: 1,
                message: 'Notes added successfully',
                finalData: newNotes.quotations
            }

        } else
        {
            myRes.message = "No notes found";
            myRes.status = 2;
        }

        res.status( 200 ).json( myRes );
    } catch ( error )
    {
        console.error( error );
        res.status( 500 ).send( 'Error registering user' );
    }
}


async function serviceInfo ( req, res )
{
    try
    {
        const { serviceId } = req.body;

        // get all users
        const service = await Service.findOne( { serviceId } );
        var myRes = {};
        if ( service )
        {
            // get one user data and update to myRes object
            myRes.data = service;
            myRes.status = 1;
        } else
        {
            myRes = {
                status: 2,
                message: 'User not found'
            }
        }

        res.status( 200 ).json( myRes );
    } catch ( error )
    {
        console.error( error );
        res.status( 500 ).send( 'Error registering user' );
    }
}


module.exports = { allServices, newServices, allNotes, newNotes, serviceInfo };
