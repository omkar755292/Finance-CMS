const User = require( '../models/User' );
const short = require( 'short-uuid' );


async function allUsers ( req, res )
{
    try
    {
        // get all users
        const users = await User.find();
        var myRes = {};
        if ( users.length > 0 )
        {
            myRes.users = users;
            myRes.status = 2;
        } else
        {
            myRes = {
                users: users,
                status: 1
            }
        }

        res.status( 200 ).json( myRes );
    } catch ( error )
    {
        console.error( error );
        res.status( 500 ).send( 'Error registering user' );
    }
}

async function newUsers ( req, res )
{
    try
    {
        console.log( req.body );
        const { name, email, phoneNumber, whatsappNumber, panNumber, aadhaarNumber, address } = req.body;
        var myRes = {};

        const user1 = await User.findOne( { panNumber } );
        const user2 = await User.findOne( { aadhaarNumber } );
        if ( !user1 && !user2 )
        {
            // create UUID
            const uid = short.generate();

            const newUser = new User( { name, email, phoneNumber, whatsappNumber, panNumber, aadhaarNumber, address, uid } );

            await newUser.save();

            myRes = {
                status: 1,
                message: 'User added successfully',
                uid: uid
            }

            res.status( 200 ).json( myRes );
            return;
        } else
        {
            myRes = {
                status: 2,
                message: 'User already exists'
            }

            res.status( 200 ).json( myRes );
            return;
        }

        res.status( 500 ).send( "Server error..." );
    } catch ( error )
    {
        console.error( error );
        res.status( 500 ).send( 'Error registering user' );
    }
}

async function userInfo ( req, res )
{
    try
    {
        // get all users
        const { uid } = req.body;
        var myRes = {};


        const user = await User.findOne( { uid } );
        if ( user )
        {
            // get one user data and update to myRes object
            myRes.data = user;
            myRes.status = 1;
        } else
        {
            myRes = {
                status: 2,
                message: 'User not found'
            }
        }

        res.status( 200 ).json( myRes );
    } catch ( error )
    {
        console.error( error );
        res.status( 500 ).send( 'Error registering user' );
    }
}





module.exports = { allUsers, newUsers, userInfo };
