// models/User.js
const mongoose = require( 'mongoose' );
//const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema( {
    uid: { type: String, required: true, unique: true },
    name: { type: String, required: false },
    email: { type: String, required: false, unique: false },
    phoneNumber: { type: String, minlength: 10, maxlength: 10, unique: false },
    whatsappNumber: { type: String, minlength: 10, maxlength: 10, },
    panNumber: { type: String, minlength: 10, maxlength: 10, unique: true },
    aadhaarNumber: { type: String, minlength: 12, maxlength: 12, unique: true },
    address: { type: String },
    status: { type: String, default: 'active' } // active/delete/cancel/approve/ongoing/complete
} );

const User = mongoose.model( 'User', userSchema );

module.exports = User;
