// routes/authRoutes.js
const express = require('express');
const { register, login } = require('../controllers/authController');
const authenticateToken = require('../middlewares/authMiddleware');

const router = express.Router();

 router.post('/auth/register', register);
router.post('/auth/login', login);
router.get('/auth/profile', authenticateToken, (req, res) => {
    res.json(req.user);
});

module.exports = router;
