// routes/orderRoutes.js
const express = require( 'express' );
const Order = require( '../models/Services' );
const multer = require( 'multer' );
const fs = require( 'fs' );
const path = require( 'path' );

const router = express.Router();

// Multer storage configuration
const storage = multer.diskStorage( {
    destination: function ( req, file, cb )
    {
        const uploadPath = path.join( __dirname, '..', 'uploads' );
        if ( !fs.existsSync( uploadPath ) )
        {
            fs.mkdirSync( uploadPath );
        }
        cb( null, uploadPath );
    },
    filename: function ( req, file, cb )
    {
        cb( null, Date.now() + '-' + file.originalname );
    }
} );

const upload = multer( { storage: storage } );

// All attributes are here
router.post( '/create', async ( req, res ) =>
{
    try
    {
        const { orderDate, orderId, amount, cashback, status, notes, paid, fullPaid, approvedBy, items } = req.body;
        const newOrder = new Order( { orderDate, orderId, amount, cashback, status, notes, paid, fullPaid, approvedBy, items } );
        await newOrder.save();
        res.status( 201 ).send();
    } catch ( error )
    {
        console.error( error );
        res.status( 500 ).send( 'Error creating order' );
    }
} );

router.get( '/fetch', async ( req, res ) =>
{
    try
    {
        const orders = await Order.find();
        res.json( orders );
    } catch ( error )
    {
        console.error( error );
        res.status( 500 ).send( 'Error fetching orders' );
    }
} );

module.exports = router;
